CREATE DATABASE IF NOT EXISTS student_management;
USE student_management;
-- Spring Data JPA/Hibernate creates app_users and students tables at application startup.
-- This file creates the database; application.properties configures connectivity.
