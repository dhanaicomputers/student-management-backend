package com.example.studentmanagement.auth;
import jakarta.persistence.*;
@Entity @Table(name="app_users")
public class AppUser {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false,unique=true) private String username;
 @Column(nullable=false) private String password;
 public AppUser(){} public AppUser(String username,String password){this.username=username;this.password=password;}
 public Long getId(){return id;} public String getUsername(){return username;} public void setUsername(String u){username=u;}
 public String getPassword(){return password;} public void setPassword(String p){password=p;}
}
