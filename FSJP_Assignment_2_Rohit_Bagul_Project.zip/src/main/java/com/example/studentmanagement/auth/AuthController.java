package com.example.studentmanagement.auth;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController @RequestMapping("/api/auth")
public class AuthController {
 private final AuthService auth; private final JwtService jwt;
 public AuthController(AuthService auth,JwtService jwt){this.auth=auth;this.jwt=jwt;}
 @PostMapping("/register") public ResponseEntity<?> register(@RequestBody Map<String,String> body){
  String username=body.get("username"), password=body.get("password");
  if(username==null||username.isBlank()||password==null||password.length()<6)
   return ResponseEntity.badRequest().body(Map.of("message","Username is required and password must have at least 6 characters"));
  try{auth.register(username,password);return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("message","User registered successfully"));}
  catch(IllegalArgumentException e){return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("message",e.getMessage()));}
 }
 @PostMapping("/login") public ResponseEntity<?> login(@RequestBody Map<String,String> body){
  String username=body.get("username"),password=body.get("password");
  if(username==null||password==null||!auth.authenticate(username,password))return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("message","Invalid username or password"));
  return ResponseEntity.ok(Map.of("token",jwt.generate(username),"tokenType","Bearer"));
 }
}
