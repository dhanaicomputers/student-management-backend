package com.example.studentmanagement.auth;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
@Service
public class AuthService {
 private final AppUserRepository users; private final PasswordEncoder encoder;
 public AuthService(AppUserRepository users,PasswordEncoder encoder){this.users=users;this.encoder=encoder;}
 public void register(String username,String password){
  if(users.existsByUsername(username)) throw new IllegalArgumentException("Username already exists");
  users.save(new AppUser(username,encoder.encode(password)));
 }
 public boolean authenticate(String username,String password){
  return users.findByUsername(username).map(u->encoder.matches(password,u.getPassword())).orElse(false);
 }
}
