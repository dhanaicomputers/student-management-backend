package com.example.studentmanagement.student;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
@Entity
@Table(name="students")
public class Student {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @NotBlank private String name;
 @Email @NotBlank @Column(nullable=false, unique=true) private String email;
 @NotBlank private String branch;
 private Integer year;
 public Student() {}
 public Student(String name,String email,String branch,Integer year){this.name=name;this.email=email;this.branch=branch;this.year=year;}
 public Long getId(){return id;} public void setId(Long id){this.id=id;}
 public String getName(){return name;} public void setName(String name){this.name=name;}
 public String getEmail(){return email;} public void setEmail(String email){this.email=email;}
 public String getBranch(){return branch;} public void setBranch(String branch){this.branch=branch;}
 public Integer getYear(){return year;} public void setYear(Integer year){this.year=year;}
}
