package com.example.studentmanagement.student;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/students")
public class StudentController {
 private final StudentRepository repository;
 public StudentController(StudentRepository repository){this.repository=repository;}
 @PostMapping public Student create(@Valid @RequestBody Student student){student.setId(null);return repository.save(student);}
 @GetMapping public List<Student> all(){return repository.findAll();}
 @GetMapping("/{id}") public ResponseEntity<Student> byId(@PathVariable Long id){return repository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());}
 @PutMapping("/{id}") public ResponseEntity<Student> update(@PathVariable Long id,@Valid @RequestBody Student input){
  return repository.findById(id).map(s->{s.setName(input.getName());s.setEmail(input.getEmail());s.setBranch(input.getBranch());s.setYear(input.getYear());return ResponseEntity.ok(repository.save(s));}).orElse(ResponseEntity.notFound().build());
 }
 @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id){
  if(!repository.existsById(id)) return ResponseEntity.notFound().build();
  repository.deleteById(id);return ResponseEntity.noContent().build();
 }
}
