# Student Management Backend — FSJP Assignment 2
**Student:** Rohit Vishal Bagul  
**Roll No.:** 130  
**Technology:** Java 17, Spring Boot, Spring Security, JWT, Spring Data JPA, MySQL, Postman

## Features
- Register and login endpoints; passwords are BCrypt-hashed.
- JWT bearer token issued after successful login.
- Student CRUD endpoints protected by JWT.
- Student fields: ID, name, email, branch, year.
- JPA/Hibernate persistence in MySQL.

## Requirements
Install JDK 17+, Maven 3.8+, MySQL 8+, and Postman.

## Run
1. Create the database using `mysql -u root -p < database/schema.sql` (or allow `createDatabaseIfNotExist=true`).
2. Set your MySQL password using environment variable `DB_PASSWORD`; optionally set `DB_USERNAME`.
3. For local coursework only, the default JWT secret is provided in `application.properties`. Replace it with a private secret for any real deployment.
4. Run `mvn spring-boot:run`.
5. Base URL: `http://localhost:8080`.

## APIs
| Method | Endpoint | Auth | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | No | Register user |
| POST | `/api/auth/login` | No | Login and receive token |
| POST | `/api/students` | Bearer JWT | Add student |
| GET | `/api/students` | Bearer JWT | List students |
| GET | `/api/students/{id}` | Bearer JWT | Get student |
| PUT | `/api/students/{id}` | Bearer JWT | Update student |
| DELETE | `/api/students/{id}` | Bearer JWT | Delete student |

## Postman examples
Register (`POST /api/auth/register`):
```json
{"username":"rohit","password":"password123"}
```
Login (`POST /api/auth/login`):
```json
{"username":"rohit","password":"password123"}
```
Copy the returned token. For student requests, set header:
`Authorization: Bearer <paste-token>`

Add student body:
```json
{"name":"Aarav Patil","email":"aarav@example.com","branch":"INFT","year":2}
```
Update student uses the same JSON body with `PUT /api/students/1`.

## Postman testing checklist
- [ ] Register user (expect 201 Created)
- [ ] Login (expect 200 OK and token)
- [ ] Get students with token (expect 200 OK)
- [ ] Get student by ID (expect 200 OK, or 404 if absent)
- [ ] Add student with token (expect 200 OK)
- [ ] Update student with token (expect 200 OK, or 404 if absent)
- [ ] Delete student with token (expect 204 No Content)
- [ ] Try a student endpoint without token (expect 401/403)

## Notes
- Actual Postman screenshots and GitHub URL must be added after running and testing the project; they are not fabricated in this submission.
- This is an educational starter project. Review and test in your local environment before submission.
